# EarthquakeMaps
A Java project to display earth quake data. 
