package com.happyspace.earthquake;

/**
 * Created by Eddie Warner on 7/4/2016.
 */
public class ClassTest {
}
